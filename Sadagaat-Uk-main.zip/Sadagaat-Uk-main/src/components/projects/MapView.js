import React, { Component } from "react";
import { Map, TileLayer, Popup, Marker } from "react-leaflet";
import i18n from "i18next";
import { withTranslation } from "react-i18next";
import "leaflet/dist/leaflet.css";
import { VenueLocationIcon } from "./VenueLocationIcon";

class MapView extends Component {
  constructor(props) {
    super(props);

    this.state = {
      currentLocation: "",
      zoom: "",
      locationName: "",
      loc: "",
      lang: "",
    };
  }

  componentDidMount() {
    this.setState({
      currentLocation: [18.057791227192226, 31.10935007293577],
      zoom: 9,
      locationName: this.props.locName,
      projectName: this.props.projectName,
    });
  }

  render() {
    const { currentLocation, zoom, locationName, projectName } = this.state;

    return (
      <Map center={currentLocation} zoom={zoom}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Marker position={currentLocation} icon={VenueLocationIcon}>
          <Popup>
            <div className="poup-text">
              <h6>{projectName}</h6>
              <p>{locationName}</p>
            </div>
          </Popup>
        </Marker>
      </Map>
    );
  }
}

export default withTranslation()(MapView);
